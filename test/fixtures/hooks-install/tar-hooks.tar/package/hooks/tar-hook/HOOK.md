---
name: tar-hook
description: tar-hook
metadata: {"ws-agent":{"events":["command:new"]}}
---

# Hook