---
name: reserved-hook
description: reserved-hook
metadata: {"ws-agent":{"events":["command:new"]}}
---

# Hook