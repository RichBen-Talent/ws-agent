---
name: zip-hook
description: Zip hook
metadata: {"ws-agent":{"events":["command:new"]}}
---

# Zip Hook